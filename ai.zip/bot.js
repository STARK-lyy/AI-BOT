require('dotenv').config();
const { Client, GatewayIntentBits, Collection, REST, Routes, SlashCommandBuilder, EmbedBuilder, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags, SectionBuilder, ThumbnailBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config.js');
const { checkOwnerPermission } = require('./utils/permissions.js');
const { isUserBlacklisted } = require('./utils/blacklist.js');
const { generateGroqResponse } = require('./services/groq.js');
const { analyzeImageWithGemini } = require('./services/gemini.js');
const { addMessageToHistory, getUserHistory, getChannelHistory, cleanupOldMessages } = require('./services/messageHistory.js');
const { setupMessageHistorySystem } = require('./db/database.js');



class Colors {
    static PURPLE = '\x1b[95m';
    static CYAN = '\x1b[96m';
    static PINK = '\x1b[38;5;213m';
    static LAVENDER = '\x1b[38;5;183m';
    static BLUE = '\x1b[94m';
    static GREEN = '\x1b[92m';
    static YELLOW = '\x1b[93m';
    static RED = '\x1b[91m';
    static WHITE = '\x1b[97m';
    static GRAY = '\x1b[90m';
    static DARK_GRAY = '\x1b[38;5;240m';
    static BOLD = '\x1b[1m';
    static DIM = '\x1b[2m';
    static UNDERLINE = '\x1b[4m';
    static RESET = '\x1b[0m';
    static STRELIZIA_PINK = '\x1b[38;5;219m';
    static STRELIZIA_PURPLE = '\x1b[38;5;141m';
    static STRELIZIA_BLUE = '\x1b[38;5;111m';
}

function displayStartupBanner() {
    const { BRAND_NAME, BOT_NAME, DEVELOPER } = config.STARTUP_CONFIG;
    
    console.clear();
    
    console.log(`\n${Colors.STRELIZIA_PINK}╭─────────────────────────────────────────────────────────────╮${Colors.RESET}`);
    console.log(`${Colors.STRELIZIA_PINK}│${Colors.RESET}                    ${Colors.BOLD}${Colors.STRELIZIA_PURPLE}✦ ${BOT_NAME} ✦${Colors.RESET}                     ${Colors.STRELIZIA_PINK}│${Colors.RESET}`);
    console.log(`${Colors.STRELIZIA_PINK}│${Colors.RESET}            ${Colors.DIM}${Colors.WHITE}Elegant • Intelligent • Sophisticated${Colors.RESET}           ${Colors.STRELIZIA_PINK}│${Colors.RESET}`);
    console.log(`${Colors.STRELIZIA_PINK}╰─────────────────────────────────────────────────────────────╯${Colors.RESET}\n`);
}

function printBotReady(botName) {
    console.log(`\n${Colors.STRELIZIA_BLUE}◆${Colors.RESET} ${Colors.BOLD}${Colors.GREEN}Authentication successful${Colors.RESET} ${Colors.DIM}→${Colors.RESET} ${Colors.STRELIZIA_PURPLE}${botName}${Colors.RESET}`);
}

function printError(message) {
    console.log(`${Colors.RED}✗${Colors.RESET} ${Colors.BOLD}Error:${Colors.RESET} ${message}`);
}

function printLoading(message) {
    console.log(`${Colors.STRELIZIA_BLUE}◆${Colors.RESET} ${Colors.DIM}Loading${Colors.RESET} ${Colors.WHITE}${message}${Colors.RESET}${Colors.DIM}...${Colors.RESET}`);
}

function printSuccess(message) {
    console.log(`${Colors.GREEN}✓${Colors.RESET} ${Colors.WHITE}${message}${Colors.RESET}`);
}

function printInfo(message) {
    console.log(`${Colors.STRELIZIA_PURPLE}ⓘ${Colors.RESET} ${Colors.WHITE}${message}${Colors.RESET}`);
}

function printElegantSeparator() {
    const separator = `${Colors.STRELIZIA_PINK}─${Colors.STRELIZIA_PURPLE}─${Colors.STRELIZIA_BLUE}─${Colors.RESET}`;
    console.log(`   ${separator.repeat(20)}`);
}

function printSystemReady() {
    printElegantSeparator();
    console.log(`\n   ${Colors.BOLD}${Colors.STRELIZIA_PURPLE}✦ System Operational ✦${Colors.RESET}`);
    console.log(`   ${Colors.DIM}${Colors.WHITE}Developed with ${Colors.STRELIZIA_PINK}♡${Colors.WHITE} by SnowAI Team${Colors.RESET}`);
    console.log(`   ${Colors.DIM}${Colors.DARK_GRAY}Ready to serve with elegance and precision${Colors.RESET}\n`);
    printElegantSeparator();
    console.log();
}

async function setPresence() {
    const { STATUS, ACTIVITY_TYPE, ACTIVITY_NAME } = config.BOT_PRESENCE;
    
    try {
        await client.user.setPresence({
            activities: [{
                name: ACTIVITY_NAME,
                type: ACTIVITY_TYPE === 'WATCHING' ? 3 : 
                      ACTIVITY_TYPE === 'LISTENING' ? 2 : 
                      ACTIVITY_TYPE === 'PLAYING' ? 0 : 0
            }],
            status: STATUS
        });
        
    } catch (error) {
        printError(`Failed to set presence: ${error.message}`);
    }
}



async function generateUserAnalysis(member, guild) {
    const user = member.user;
    
    const userInfo = {
        username: user.username,
        displayName: member.displayName,
        discriminator: user.discriminator,
        id: user.id,
        accountCreated: user.createdAt,
        joinedServer: member.joinedAt,
        roles: member.roles.cache
            .filter(role => role.name !== '@everyone')
            .map(role => role.name)
            .slice(0, 10),
        isBot: user.bot,
        avatar: user.displayAvatarURL(),
        status: member.presence?.status || 'offline',
        activities: member.presence?.activities?.map(activity => ({
            name: activity.name,
            type: activity.type,
            details: activity.details
        })) || [],
        nickname: member.nickname,
        permissions: member.permissions.toArray().slice(0, 15),
        highestRole: member.roles.highest.name,
        roleColor: member.roles.highest.color
    };

    const analysisPrompt = `Analyze this Discord user's profile data and provide a concise, friendly summary about who they are in the server community. Focus on their roles, activity, and what kind of member they appear to be.

User Data:
- Username: ${userInfo.username}
- Display Name: ${userInfo.displayName}
- Account Created: ${userInfo.accountCreated.toDateString()}
- Joined Server: ${userInfo.joinedServer.toDateString()}
- Roles: ${userInfo.roles.join(', ') || 'None'}
- Highest Role: ${userInfo.highestRole}
- Bot Account: ${userInfo.isBot}
- Current Status: ${userInfo.status}
- Activities: ${userInfo.activities.map(a => a.name).join(', ') || 'None'}
- Nickname: ${userInfo.nickname || 'None'}
- Key Permissions: ${userInfo.permissions.slice(0, 5).join(', ')}

Write a short paragraph (under 200 words) describing this user's profile, their role in the server, and what kind of member they appear to be. Be respectful and focus on positive aspects. If they're a bot, mention that. If they have special roles or permissions, highlight those appropriately.`;

    const aiSummary = await generateGroqResponse(analysisPrompt, "You are a helpful assistant that analyzes Discord user profiles. Be respectful, positive, and concise.", []);

    const response = `🔍 **User Profile: ${userInfo.displayName}**\n\n${aiSummary}\n\n📊 **Quick Stats:**\n• Joined: ${userInfo.joinedServer.toDateString()}\n• Roles: ${userInfo.roles.length}\n• Status: ${userInfo.status}\n• Highest Role: ${userInfo.highestRole}`;

    return response;
}

async function sendLongMessage(message, text) {
    if (text.length <= 2000) {
        return await message.reply(text);
    }
    
    const chunks = [];
    let currentChunk = '';
    const lines = text.split('\n');
    
    for (const line of lines) {
        if (currentChunk.length + line.length + 1 <= 1900) {
            currentChunk += (currentChunk ? '\n' : '') + line;
        } else {
            if (currentChunk) {
                chunks.push(currentChunk);
                currentChunk = line;
            } else {
                chunks.push(line.substring(0, 1900));
                currentChunk = line.substring(1900);
            }
        }
    }
    
    if (currentChunk) {
        chunks.push(currentChunk);
    }
    
    await message.reply(chunks[0]);
    
    for (let i = 1; i < chunks.length; i++) {
        await message.channel.send(chunks[i]);
    }
}

async function sendImageAnalysisContainer(message, analysisText) {
    try {
        const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require('discord.js');
        
        let totalCharCount = 60;
        const sections = analysisText.split(/(?=\*\*[🔍🧠❌💡🛡️🖼️🎨💬][^*]+\*\*)/);
        const sectionsToProcess = sections.length > 1 ? sections : [analysisText];
        
        const totalTextLength = analysisText.length;
        if (totalTextLength > 8000) {
            await sendLongMessage(message, `🔍 **Image Analysis**\n*AI-powered visual content analysis*\n\n${analysisText}`);
            return;
        }
        
        const analysisContainer = new ContainerBuilder();
        
        analysisContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 🔍 Image Analysis\n*AI-powered visual content analysis*')
        );
        
        analysisContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
        );
        
        let componentsAdded = 0;
        const maxComponents = 12; // Increased limit
        
        let contentChunks;
        if (sectionsToProcess.length === 1) {
            const text = sectionsToProcess[0];
            const paragraphs = text.split(/\n\s*\n/);
            contentChunks = [];
            
            for (const paragraph of paragraphs) {
                if (paragraph.length <= 1500) {
                    contentChunks.push(paragraph.trim());
                } else {
                    const sentences = paragraph.split(/(?<=[.!?])\s+/);
                    let currentChunk = '';
                    for (const sentence of sentences) {
                        if (currentChunk.length + sentence.length + 1 <= 1500) {
                            currentChunk += (currentChunk ? ' ' : '') + sentence;
                        } else {
                            if (currentChunk) {
                                contentChunks.push(currentChunk.trim());
                                currentChunk = sentence;
                            } else {
                                contentChunks.push(sentence.substring(0, 1500).trim());
                            }
                        }
                    }
                    if (currentChunk) {
                        contentChunks.push(currentChunk.trim());
                    }
                }
            }
        } else {
            contentChunks = sectionsToProcess.map(section => {
                const trimmed = section.trim();
                return trimmed.length > 1500 ? trimmed.substring(0, 1500) + '...' : trimmed;
            });
        }
        
        for (let i = 0; i < contentChunks.length && componentsAdded < maxComponents; i++) {
            const chunk = contentChunks[i];
            if (!chunk) continue;
            
            analysisContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(chunk)
            );
            
            componentsAdded++;
            
            if (i < contentChunks.length - 1 && componentsAdded < maxComponents) {
                analysisContainer.addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
                );
            }
        }
        
        await message.reply({
            components: [analysisContainer],
            flags: MessageFlags.IsComponentsV2
        });
    } catch (error) {
        console.error('Error sending image analysis container:', error);
        const truncatedText = analysisText.length > 1800 ? 
            analysisText.substring(0, 1800) + '...\n\n*Analysis truncated due to length*' : 
            analysisText;
        await message.reply(`🔍 **Image Analysis**\n\n${truncatedText}`);
    }
}

const { Partials } = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel, Partials.Message]
});

client.commands = new Collection();

let enabledChannels = {};
try {
    const channelsData = fs.readFileSync('./data/channels.json', 'utf8');
    enabledChannels = JSON.parse(channelsData);
} catch (error) {
    console.log('No channels data found, starting with empty configuration');
    enabledChannels = {};
}

let systemPrompt = config.BOT_CONFIG.DEFAULT_SYSTEM_PROMPT;
let imageAnalysisPrompt = config.BOT_CONFIG.DEFAULT_IMAGE_ANALYSIS_PROMPT;
try {
    const promptData = fs.readFileSync('./data/systemprompt.json', 'utf8');
    const promptObj = JSON.parse(promptData);
    systemPrompt = promptObj.prompt || config.BOT_CONFIG.DEFAULT_SYSTEM_PROMPT;
    imageAnalysisPrompt = promptObj.imageAnalysisPrompt || config.BOT_CONFIG.DEFAULT_IMAGE_ANALYSIS_PROMPT;
} catch (error) {
    console.log('No system prompt data found, using default');
}

const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
const commands = [];

for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.data.name, command);
    commands.push(command.data.toJSON());
}

async function registerCommands() {
    try {
        const rest = new REST({ version: '10' }).setToken(config.DISCORD_TOKEN);
        
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commands },
        );
        
    } catch (error) {
        printError(`Failed to register commands: ${error.message}`);
    }
}

client.once('ready', async () => {
    if (config.STARTUP_CONFIG.SHOW_BANNER) {
        displayStartupBanner();
    }
    
    printLoading('Initializing Discord presence');
    await setPresence();
    printSuccess('Discord presence configured');
    
    printLoading('Synchronizing application commands');
    await registerCommands();
    printSuccess('Command synchronization complete');
    
    printLoading('Configuring message history system');
    setupMessageHistorySystem();
    setInterval(async () => {
        await cleanupOldMessages();
    }, 10 * 60 * 1000);
    printSuccess('Message history system initialized');
    
    printBotReady(client.user.tag);
    printSystemReady();
});

client.on('interactionCreate', async interaction => {
    console.log(`=== INTERACTION EVENT TRIGGERED ===`);
    console.log(`Interaction type: ${interaction.type}, User: ${interaction.user.tag}`);
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction, { enabledChannels, systemPrompt, imageAnalysisPrompt });
        } catch (error) {
            console.error('Error executing command:', error);
            const errorMessage = 'There was an error while executing this command!';
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: errorMessage, ephemeral: true });
            } else {
                await interaction.reply({ content: errorMessage, ephemeral: true });
            }
        }
    } else if (interaction.isModalSubmit()) {
        try {
            await handleModalSubmit(interaction);
        } catch (error) {
            console.error('Error handling modal submit:', error);
            const errorMessage = 'There was an error while processing your submission!';
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: errorMessage, ephemeral: true });
            } else {
                await interaction.reply({ content: errorMessage, ephemeral: true });
            }
        }
    } else if (interaction.isStringSelectMenu() || interaction.isButton()) {
        try {
            await handleHelpInteractions(interaction);
        } catch (error) {
            console.error('Error handling help interaction:', error);
            const errorMessage = 'There was an error while processing your request!';
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: errorMessage, ephemeral: true });
            } else {
                await interaction.reply({ content: errorMessage, ephemeral: true });
            }
        }
    }
});

async function handleHelpInteractions(interaction) {
    const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, SeparatorSpacingSize, ButtonStyle, MessageFlags } = require('discord.js');
    
    if (interaction.customId === 'help_refresh') {
        await interaction.deferUpdate();
        const helpCommand = client.commands.get('help');
        if (helpCommand) {
            await helpCommand.execute(interaction, true);
        }
    
    } else if (interaction.customId === 'help_examples') {
        const exampleContainer = new ContainerBuilder()
            .setAccentColor(0x57F287);

        exampleContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 📝 Usage Examples\n*Practical examples of how to use SnowAI AI*')
        );
        exampleContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
        );

        exampleContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## 💬 Natural Conversation Examples')
        );
        
        exampleContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**🐍 Python Help**\n```\n"Help me debug this Python error: NameError"\n"How do I use list comprehensions?"\n"Explain decorators in Python"\n```'),
            new TextDisplayBuilder().setContent('**🌐 Web Development**\n```\n"How do I create a REST API in Node.js?"\n"Explain async/await in JavaScript"\n"Help with React hooks"\n```'),
            new TextDisplayBuilder().setContent('**🖼️ Image Analysis**\n```\n[Upload code screenshot] "What\'s wrong with this code?"\n[Upload diagram] "Explain this architecture"\n[Upload UI mockup] "How would you implement this?"\n```')
        );

        exampleContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        exampleContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## 👤 User Analysis Examples')
        );

        exampleContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**User Analysis**\n```\n"who is @username" - Natural language\n/whois @username - Slash command\n```')
        );

        exampleContainer.addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('help_back_to_main')
                    .setLabel('← Back to Help Menu')
                    .setStyle(ButtonStyle.Secondary)
            )
        );

        await interaction.update({
            components: [exampleContainer],
            flags: MessageFlags.IsComponentsV2
        });
    } else if (interaction.customId === 'help_features') {
        const featureContainer = new ContainerBuilder()
            .setAccentColor(0xFEE75C);

        featureContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# ✨ AI Features Overview\n*Cutting-edge artificial intelligence capabilities*')
        );
        featureContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
        );

        featureContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**🚀 ChatGPT-5 Integration**\nPowered by OpenAI\'s latest GPT-5 model through OpenRouter for advanced reasoning and programming assistance.'),
            new TextDisplayBuilder().setContent('**👁️ Google Gemini Vision**\nAdvanced image analysis that can read code screenshots, understand diagrams, analyze UI mockups, and explain visual content.'),
            new TextDisplayBuilder().setContent('**🧠 Conversation Memory**\nMaintains context within channels, remembering your conversation history for more intelligent and coherent responses.')
        );

        featureContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        featureContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**🌍 Real-time Weather Data**\nGet current weather information for any city worldwide with detailed atmospheric conditions.'),
            new TextDisplayBuilder().setContent('**👤 AI User Analysis**\nAnalyze Discord user profiles with AI-generated insights about roles, activity, and server participation.'),
            new TextDisplayBuilder().setContent('**📱 Components v2 UI**\nModern interactive interface with categorized menus, buttons, and rich content displays.')
        );

        featureContainer.addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('help_back_to_main')
                    .setLabel('← Back to Help Menu')
                    .setStyle(ButtonStyle.Secondary)
            )
        );

        await interaction.update({
            components: [featureContainer],
            flags: MessageFlags.IsComponentsV2
        });
    } else if (interaction.customId === 'help_support') {
        const supportContainer = new ContainerBuilder()
            .setAccentColor(0x57F287);

        supportContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 🆘 Getting Support\n*Need help? Here\'s how to get assistance*')
        );
        supportContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
        );

        supportContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## 🔧 Technical Support')
        );

        supportContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('**SnowAI Team Server**\n• Join: `https://discord.gg/8wfT8SfB5Z`\n• Get support in our Discord community\n• Report issues and get help from our team'),
            new TextDisplayBuilder().setContent('**Bot Creator - itsfizys**\n• Co-founder & Developer of SnowAI AI\n• Available in SnowAI Team server\n• Handles all bot-related issues and feature requests')
        );

        supportContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        supportContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('## 📋 Before Requesting Support')
        );

        supportContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('1. **Check this help menu** for basic usage\n2. **Try the examples** provided in this guide\n3. **Include error messages** when reporting issues\n4. **Describe what you were trying to do** when the problem occurred')
        );

        supportContainer.addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('help_back_to_main')
                    .setLabel('← Back to Help Menu')
                    .setStyle(ButtonStyle.Secondary)
            )
        );

        await interaction.update({
            components: [supportContainer],
            flags: MessageFlags.IsComponentsV2
        });
    } else if (interaction.customId === 'help_back_to_main') {
        await interaction.deferUpdate();
        const helpCommand = client.commands.get('help');
        if (helpCommand) {
            await helpCommand.execute(interaction, true);
        }
    } else if (interaction.customId === 'help_category_select') {
        const selectedValue = interaction.values[0];
        
        if (selectedValue === 'home') {
            await interaction.deferUpdate();
            const helpCommand = client.commands.get('help');
            if (helpCommand) {
                await helpCommand.execute(interaction, true);
            }
            return;
        }
        
        const categoryContainer = new ContainerBuilder()
            .setAccentColor(0x000000);

        if (selectedValue === 'user_commands') {
            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('# 👤 User Commands')
            );
            categoryContainer.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
            );

            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('**/whois [user]** - AI analysis of any Discord user\n**/history** - View your conversation history\n**/clearhistory** - Delete all your history')
            );

        } else if (selectedValue === 'ai_features') {
            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('# 🧠 AI Features')
            );
            categoryContainer.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
            );

            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('**🤖 Text AI** - Groq Llama3 for fast, intelligent responses\n**👁️ Vision AI** - Google Gemini for image analysis\n**💬 Context-Aware** - Remembers conversation history\n**/analyse** - Analyze images with custom prompts')
            );

        } else if (selectedValue === 'channel_management') {
            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('# ⚙️ Channel Management')
            );
            categoryContainer.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
            );

            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('**/enable** - Enable AI responses in this channel\n**/disable** - Disable AI responses in this channel\n\n*Requires Manage Server permission*')
            );

        } else if (selectedValue === 'bot_config') {
            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('# 🔧 Bot Configuration')
            );
            categoryContainer.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
            );

            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('**/showsystemprompt** - View AI personality settings\n**/editsystemprompt** - Modify AI behavior\n**/showimageprompt** - View image analysis settings\n**/editimageprompt** - Customize image analysis\n**/blacklistadd [user]** - Block user from AI\n**/blacklistremove [user]** - Unblock user\n**/blacklistlist** - View all blacklisted users\n\n*Owner only commands*')
            );

        } else if (selectedValue === 'natural_language') {
            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('# 💬 Natural Language')
            );
            categoryContainer.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
            );

            categoryContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('**🏷️ Mention** - @SnowAI AI + your message\n**📩 DMs** - Direct message the bot anytime\n**🖼️ Images** - Upload images for AI analysis')
            );
        }

        categoryContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        categoryContainer.addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('help_category_select')
                    .setPlaceholder('Select a command category...')
                    .addOptions([
                        new StringSelectMenuOptionBuilder()
                            .setLabel('Home')
                            .setValue('home')
                            .setDescription('Return to main help menu'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('User Commands')
                            .setValue('user_commands')
                            .setDescription('Commands available to everyone'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('AI Features')
                            .setValue('ai_features')
                            .setDescription('Smart AI capabilities'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('Channel Management')
                            .setValue('channel_management')
                            .setDescription('Enable/disable AI (Owner only)'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('Bot Configuration')
                            .setValue('bot_config')
                            .setDescription('System settings (Owner only)'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('Natural Language')
                            .setValue('natural_language')
                            .setDescription('Chat directly with AI')
                    ])
            )
        );

        await interaction.update({
            components: [categoryContainer],
            flags: MessageFlags.IsComponentsV2
        });
    }
}

async function handleModalSubmit(interaction) {
    const { checkOwnerPermission } = require('./utils/permissions.js');
    
    if (!checkOwnerPermission(interaction.user.id)) {
        await interaction.reply({
            content: 'You do not have permission to use this feature.',
            ephemeral: true
        });
        return;
    }

    if (interaction.customId === 'editsystemprompt') {
        const newPrompt = interaction.fields.getTextInputValue('systemPromptInput');
        
        if (newPrompt.length > 2000) {
            await interaction.reply({
                content: 'System prompt is too long. Please keep it under 2000 characters.',
                ephemeral: true
            });
            return;
        }

        systemPrompt = newPrompt;
        const promptData = { prompt: newPrompt, imageAnalysisPrompt: imageAnalysisPrompt };
        fs.writeFileSync('./data/systemprompt.json', JSON.stringify(promptData, null, 2));

        await interaction.reply({
            content: `✅ System prompt has been updated successfully!\n\n**New prompt preview:**\n\`\`\`${newPrompt.substring(0, 500)}${newPrompt.length > 500 ? '...' : ''}\`\`\``,
            ephemeral: true
        });
    } else if (interaction.customId === 'editimageprompt') {
        const newPrompt = interaction.fields.getTextInputValue('imagePromptInput');
        
        if (newPrompt.length > 2000) {
            await interaction.reply({
                content: 'Image analysis prompt is too long. Please keep it under 2000 characters.',
                ephemeral: true
            });
            return;
        }

        imageAnalysisPrompt = newPrompt;
        const promptData = { prompt: systemPrompt, imageAnalysisPrompt: newPrompt };
        fs.writeFileSync('./data/systemprompt.json', JSON.stringify(promptData, null, 2));

        await interaction.reply({
            content: `✅ Image analysis prompt has been updated successfully!\n\n**New prompt preview:**\n\`\`\`${newPrompt.substring(0, 500)}${newPrompt.length > 500 ? '...' : ''}\`\`\``,
            ephemeral: true
        });
    }
}



client.on('messageCreate', async message => {
    if (message.author.bot) {
        return;
    }

    if (isUserBlacklisted(message.author.id)) {
        return;
    }


    const isMentioned = message.mentions.has(client.user);
    
    const isRoleMentioned = message.guild && message.mentions.roles.some(role => 
        message.guild.members.cache.get(client.user.id).roles.cache.has(role.id)
    ) && !message.mentions.everyone;
    
    const isReplyToBot = message.reference && message.reference.messageId && 
        message.channel.messages.cache.get(message.reference.messageId)?.author.id === client.user.id;
    
    const isDM = message.channel.type === 1;
    
    const isChannelEnabled = message.guild ? enabledChannels[message.channel.id] : true;

    if (!isDM && !isMentioned && !isRoleMentioned && !isReplyToBot && !isChannelEnabled) {
        return;
    }

    try {
        if (isMentioned && message.content.trim() === `<@${client.user.id}>`) {
            
            const introContainer = new ContainerBuilder()
                .setAccentColor(0x000000)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent('# SnowAI AI')
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
                )
                .addSectionComponents(
                    new SectionBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Greetings,** <@${message.author.id}>`),
                            new TextDisplayBuilder().setContent('SnowAI AI is a refined and intelligent presence—elegant, calm, and built to empower your server.\n\nIt listens when needed, acts with precision, and adds a layer of style to every interaction.\n\nFrom debugging to code analysis, it does it all—quietly, efficiently, and beautifully.')
                        )
                        .setThumbnailAccessory(new ThumbnailBuilder().setURL(client.user.displayAvatarURL({ size: 128 })))
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent('Made By SnowAI Team')
                );

            await message.reply({
                components: [introContainer],
                flags: MessageFlags.IsComponentsV2
            });
            return;
        }

        if (message.attachments.size > 0) {
            const imageAttachments = message.attachments.filter(attachment => 
                attachment.contentType && attachment.contentType.startsWith('image/')
            );
            
            if (imageAttachments.size > 0) {
                await message.channel.sendTyping();
                
                try {
                    for (const [index, attachment] of imageAttachments.entries()) {
                        let enhancedPrompt = imageAnalysisPrompt;
                        if (message.content.trim()) {
                            enhancedPrompt = `${imageAnalysisPrompt}\n\nUser's additional context/question: "${message.content.trim()}"`;
                        }
                        
                        if (imageAttachments.size > 1) {
                            enhancedPrompt += `\n\nNote: This is image ${index + 1} of ${imageAttachments.size} images sent together.`;
                        }
                        
                        const analysisPromise = analyzeImageWithGemini(attachment.url, enhancedPrompt);
                        const timeoutPromise = new Promise((_, reject) => 
                            setTimeout(() => reject(new Error('Analysis timeout')), 30000)
                        );
                        
                        const imageAnalysis = await Promise.race([analysisPromise, timeoutPromise]);
                        
                        const userMessage = message.content.trim() ? 
                            `${message.content.trim()} [Image ${index + 1}/${imageAttachments.size} attached]` : 
                            `[Image ${index + 1}/${imageAttachments.size} attached]`;
                        await addMessageToHistory(message.author.id, message.channel.id, userMessage, 'user');
                        
                        await addMessageToHistory(message.author.id, message.channel.id, imageAnalysis, 'assistant');
                        
                        await sendImageAnalysisContainer(message, imageAnalysis);
                        
                        if (index < imageAttachments.size - 1) {
                            await new Promise(resolve => setTimeout(resolve, 1000));
                        }
                    }
                    return;
                } catch (error) {
                    console.error('Error analyzing image:', error);
                    let errorMessage = 'I encountered an error while analyzing the image.';
                    
                    if (error.message === 'Analysis timeout') {
                        errorMessage = 'Image analysis is taking longer than expected. Please try again with a smaller image.';
                    }
                    
                    await message.reply(errorMessage);
                    return;
                }
            }
        }

        if (!message.content.trim()) {
            return;
        }

        try {
            await message.channel.sendTyping();
        } catch (permError) {
            console.log('Cannot send typing indicator - missing permissions');
        }

        await addMessageToHistory(message.author.id, message.channel.id, message.content, 'user');
        
        const channelHistory = await getChannelHistory(message.author.id, message.channel.id, 12);
        
        const responseText = await generateGroqResponse(message.content, systemPrompt, channelHistory);
        
        await addMessageToHistory(message.author.id, message.channel.id, responseText, 'assistant');

        if (responseText) {
            await sendLongMessage(message, responseText);
        }

    } catch (error) {
        console.error('Error processing message:', error);
        try {
            await message.reply('Sorry, I encountered an error while processing your message.');
        } catch (permError) {
            console.log('Cannot send error message - missing permissions in channel:', message.channel.id);
        }
    }
});

client.on('error', error => {
    console.error('Discord client error:', error);
});

process.on('unhandledRejection', error => {
    console.error('Unhandled promise rejection:', error);
});

module.exports = {
    client,
    enabledChannels,
    systemPrompt,
    imageAnalysisPrompt,
    updateSystemPrompt: (newPrompt) => {
        systemPrompt = newPrompt;
    },
    updateImageAnalysisPrompt: (newPrompt) => {
        imageAnalysisPrompt = newPrompt;
    },
    saveChannelsData: () => {
        fs.writeFileSync('./data/channels.json', JSON.stringify(enabledChannels, null, 2));
    },
    saveSystemPrompt: (prompt) => {
        const promptData = { prompt: prompt, imageAnalysisPrompt: imageAnalysisPrompt };
        fs.writeFileSync('./data/systemprompt.json', JSON.stringify(promptData, null, 2));
    },
    saveImageAnalysisPrompt: (prompt) => {
        const promptData = { prompt: systemPrompt, imageAnalysisPrompt: prompt };
        fs.writeFileSync('./data/systemprompt.json', JSON.stringify(promptData, null, 2));
    }
};

client.login(config.DISCORD_TOKEN);

/*
@Author: itsfizys & SnowAI Team
Community: https://discord.gg/8wfT8SfB5Z (SnowAI Team)
Reach out for support or credits.
*/

