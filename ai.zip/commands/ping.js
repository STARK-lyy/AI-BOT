
const { SlashCommandBuilder, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, ThumbnailBuilder, MessageFlags, SectionBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Check bot latency and API response times'),
    
    async execute(interaction) {
        await interaction.deferReply();
        
        const startTime = Date.now();
        
        const botPing = interaction.client.ws.ping;
        
        let groqPing = 'Timeout';
        try {
            const groqStart = Date.now();
            const { generateGroqResponse } = require('../services/groq.js');
            await generateGroqResponse('ping', 'Respond with just "pong"', []);
            groqPing = `${Date.now() - groqStart}ms`;
        } catch (error) {
            groqPing = 'Error';
        }
        
        let geminiPing = 'Timeout';
        try {
            const geminiStart = Date.now();
            const { analyzeImageWithGemini } = require('../services/gemini.js');
            await analyzeImageWithGemini('https://via.placeholder.com/1x1', 'Simple test');
            geminiPing = `${Date.now() - geminiStart}ms`;
        } catch (error) {
            if (error.message && !error.message.includes('timeout')) {
                geminiPing = 'Error';
            } else {
                geminiPing = 'Timeout';
            }
        }
        
        const totalTime = Date.now() - startTime;
        
        const pingContainer = new ContainerBuilder();
        
        pingContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 🏓 Latency')
        );
        
        pingContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
        );
        
        pingContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Bot Latency**\n${botPing}ms`),
            new TextDisplayBuilder().setContent(`**Command Response**\n${totalTime}ms`),
            new TextDisplayBuilder().setContent(`**Groq API**\n${groqPing}`),
            new TextDisplayBuilder().setContent(`**Gemini API**\n${geminiPing}`)
        );
        
        await interaction.editReply({
            components: [pingContainer],
            flags: MessageFlags.IsComponentsV2
        });
    }
};

/*
@Author: itsfizys & SnowAI Team
Community: https://discord.gg/8wfT8SfB5Z (SnowAI Team)
Reach out for support or credits.
*/
