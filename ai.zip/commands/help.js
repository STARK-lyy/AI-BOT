
const {
    SlashCommandBuilder,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
    SeparatorSpacingSize
} = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('View all available commands and their usage'),

    async execute(interaction, isRefresh = false) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# 🤖 SnowAI AI\n*Your intelligent coding companion*')
        );

        container.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('Built with precision by **SnowAI Team**\nSelect a category to explore commands.')
        );

        container.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        container.addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('help_category_select')
                    .setPlaceholder('📋 Select a command category...')
                    .addOptions([
                        new StringSelectMenuOptionBuilder()
                            .setLabel('Home')
                            .setValue('home')
                            .setDescription('Return to main help menu'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('User Commands')
                            .setValue('user_commands')
                            .setDescription('Commands available to everyone'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('AI Features')
                            .setValue('ai_features')
                            .setDescription('Smart AI capabilities'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('Channel Management')
                            .setValue('channel_management')
                            .setDescription('Enable/disable AI (Manage Server)'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('Bot Configuration')
                            .setValue('bot_config')
                            .setDescription('System settings (Owner only)'),
                        new StringSelectMenuOptionBuilder()
                            .setLabel('Natural Language')
                            .setValue('natural_language')
                            .setDescription('Chat directly with AI')
                    ])
            )
        );

        if (isRefresh) {
            if (interaction.replied || interaction.deferred) {
                await interaction.editReply({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            } else {
                await interaction.reply({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            }
        } else {
            await interaction.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};

/*
@Author: itsfizys & SnowAI Team
Community: https://discord.gg/8wfT8SfB5Z (SnowAI Team)
Reach out for support or credits.
*/
