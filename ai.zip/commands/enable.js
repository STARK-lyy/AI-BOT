const { SlashCommandBuilder, PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('enable')
        .setDescription('Enable AI bot responses in this channel')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, { enabledChannels }) {
        if (!interaction.guild) {
            await interaction.reply({
                content: 'This command can only be used in a server.',
                ephemeral: true
            });
            return;
        }

        const channelId = interaction.channel.id;
        
        enabledChannels[channelId] = true;
        
        const { saveChannelsData } = require('../bot.js');
        saveChannelsData();

        const enableContainer = new ContainerBuilder();

        enableContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent('# ✅ AI Responses Enabled')
        );
        
        enableContainer.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        enableContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`AI bot responses have been **enabled** in <#${channelId}>.`)
        );

        await interaction.reply({
            components: [enableContainer],
            flags: MessageFlags.IsComponentsV2
        });
    }
};

/*
@Author: itsfizys
Community: https://discord.gg/8wfT8SfB5Z (SnowAI Development)
Reach out for support or credits.
*/

