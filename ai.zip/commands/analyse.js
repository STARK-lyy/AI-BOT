const { SlashCommandBuilder } = require('discord.js');
const { analyzeImageWithGemini } = require('../services/gemini.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('analyse')
        .setDescription('Debug image analysis with detailed logging')
        .addAttachmentOption(option =>
            option.setName('image')
                .setDescription('Image to analyze')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply();
        
        const attachment = interaction.options.getAttachment('image');
        
        if (!attachment) {
            await interaction.editReply('Please provide an image to analyze.');
            return;
        }

        if (!attachment.contentType || !attachment.contentType.startsWith('image/')) {
            await interaction.editReply('Please provide a valid image file.');
            return;
        }

        console.log('=== DEBUG ANALYSE COMMAND ===');
        console.log('Attachment URL:', attachment.url);
        console.log('Content Type:', attachment.contentType);
        console.log('File size:', attachment.size);
        
        try {
            const result = await analyzeImageWithGemini(attachment.url);
            
            try {
                const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require('discord.js');
                
                if (result.length > 8000) {
                    const chunks = [];
                    let currentChunk = '';
                    const lines = result.split('\n');
                    
                    for (const line of lines) {
                        if (currentChunk.length + line.length + 1 <= 1900) {
                            currentChunk += (currentChunk ? '\n' : '') + line;
                        } else {
                            if (currentChunk) {
                                chunks.push(currentChunk);
                                currentChunk = line;
                            } else {
                                chunks.push(line.substring(0, 1900));
                            }
                        }
                    }
                    if (currentChunk) chunks.push(currentChunk);
                    
                    await interaction.editReply({
                        content: `🔍 **Debug Image Analysis**\n*Detailed analysis with debug information*\n\n${chunks[0]}`
                    });
                    
                    for (let i = 1; i < chunks.length && i < 5; i++) {
                        await interaction.followUp({
                            content: chunks[i],
                            ephemeral: false
                        });
                    }
                    return;
                }
                
                const analysisContainer = new ContainerBuilder();
                
                analysisContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent('# 🔍 Debug Image Analysis\n*Detailed analysis with debug information*')
                );
                
                analysisContainer.addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true)
                );
                
                const sections = result.split(/(?=\*\*[🔍🧠❌💡🛡️🖼️🎨💬][^*]+\*\*)/);
                const sectionsToProcess = sections.length > 1 ? sections : [result];
                
                let componentsAdded = 0;
                const maxComponents = 12; // Increased from 5 to 12
                
                let contentChunks;
                if (sectionsToProcess.length === 1) {
                    const text = sectionsToProcess[0];
                    const paragraphs = text.split(/\n\s*\n/);
                    contentChunks = [];
                    
                    for (const paragraph of paragraphs) {
                        if (paragraph.length <= 1500) { // Increased from 800 to 1500
                            contentChunks.push(paragraph.trim());
                        } else {
                            const sentences = paragraph.split(/(?<=[.!?])\s+/);
                            let currentChunk = '';
                            for (const sentence of sentences) {
                                if (currentChunk.length + sentence.length + 1 <= 1500) {
                                    currentChunk += (currentChunk ? ' ' : '') + sentence;
                                } else {
                                    if (currentChunk) {
                                        contentChunks.push(currentChunk.trim());
                                        currentChunk = sentence;
                                    } else {
                                        contentChunks.push(sentence.substring(0, 1500).trim());
                                    }
                                }
                            }
                            if (currentChunk) {
                                contentChunks.push(currentChunk.trim());
                            }
                        }
                    }
                } else {
                    contentChunks = sectionsToProcess.map(section => {
                        const trimmed = section.trim();
                        return trimmed.length > 1500 ? trimmed.substring(0, 1500) + '...' : trimmed;
                    });
                }
                
                for (let i = 0; i < contentChunks.length && componentsAdded < maxComponents; i++) {
                    const chunk = contentChunks[i];
                    if (!chunk) continue;
                    
                    analysisContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(chunk)
                    );
                    
                    componentsAdded++;
                    
                    if (i < contentChunks.length - 1 && componentsAdded < maxComponents) {
                        analysisContainer.addSeparatorComponents(
                            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
                        );
                    }
                }
                
                await interaction.editReply({
                    components: [analysisContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (containerError) {
                console.error('Container error, falling back to regular message:', containerError);
                const truncatedText = result.length > 1800 ? 
                    result.substring(0, 1800) + '...\n\n*Analysis truncated due to length*' : 
                    result;
                await interaction.editReply({
                    content: `🔍 **Debug Image Analysis**\n\n${truncatedText}`
                });
            }
        } catch (error) {
            console.error('Debug command error:', error);
            await interaction.editReply('❌ Failed to analyze image. Check console for details.');
        }
    },
};

/*
@Author: itsfizys
Community: https://discord.gg/8wfT8SfB5Z (SnowAI Development)
Reach out for support or credits.
*/
