const config = require('../config.js');

function checkOwnerPermission(userId) {
    return config.OWNER_IDS.includes(userId);
}

module.exports = {
    checkOwnerPermission
};

/*
@Author: itsfizys
Community: https://discord.gg/8wfT8SfB5Z (SnowAI Development)
Reach out for support or credits.
*/

