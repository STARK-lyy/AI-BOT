const { OpenAI } = require('openai');
const config = require('../config.js');

const groq = new OpenAI({
    apiKey: config.GROQ_API_KEY,
    baseURL: 'https://api.groq.com/openai/v1'
});

/**
 * Generate response using Groq API
 * @param {string} prompt - User prompt
 * @param {string} systemPrompt - System prompt for the AI
 * @param {Array} history - Previous message history
 * @returns {Promise<string>} Generated response
 */
async function generateGroqResponse(prompt, systemPrompt, history = []) {
    try {
        const messages = [
            { role: 'system', content: systemPrompt }
        ];

        if (history && history.length > 0) {
            const filteredHistory = history.map(msg => ({
                role: msg.role,
                content: msg.content
            }));
            messages.push(...filteredHistory);
        }

        messages.push({ role: 'user', content: prompt });

        const response = await groq.chat.completions.create({
            model: config.BOT_CONFIG.GROQ_MODEL,
            messages: messages,
            max_tokens: config.BOT_CONFIG.MAX_TOKENS,
            temperature: config.BOT_CONFIG.TEMPERATURE,
            stream: false
        });

        return response.choices[0].message.content;
    } catch (error) {
        console.error('Error generating Groq response:', error);
        throw new Error(`Groq API error: ${error.message}`);
    }
}

module.exports = {
    generateGroqResponse
};