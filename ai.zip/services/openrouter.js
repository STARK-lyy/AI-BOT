const { OpenAI } = require('openai');
const config = require('../config.js');

const openrouter = new OpenAI({
    apiKey: config.OPENROUTER_API_KEY,
    baseURL: 'https://openrouter.ai/api/v1'
});

/**
 * Generate response using OpenRouter API with ChatGPT-5
 * @param {string} prompt - User prompt
 * @param {string} systemPrompt - System prompt for the AI
 * @param {Array} history - Previous message history
 * @returns {Promise<string>} Generated response
 */
async function generateOpenRouterResponse(prompt, systemPrompt, history = []) {
    try {
        const messages = [
            { role: 'system', content: systemPrompt }
        ];

        if (history && history.length > 0) {
            const filteredHistory = history.map(msg => ({
                role: msg.role,
                content: msg.content
            }));
            messages.push(...filteredHistory);
        }

        messages.push({ role: 'user', content: prompt });

        const response = await openrouter.chat.completions.create({
            model: config.BOT_CONFIG.OPENROUTER_MODEL,
            messages: messages,
            max_tokens: config.BOT_CONFIG.MAX_TOKENS,
            temperature: config.BOT_CONFIG.TEMPERATURE,
            stream: false,
            headers: {
                "HTTP-Referer": "https://replit.com",
                "X-Title": "SnowAI AI Discord Bot"
            }
        });

        return response.choices[0].message.content;
    } catch (error) {
        console.error('Error generating OpenRouter response:', error);
        throw new Error(`OpenRouter API error: ${error.message}`);
    }
}

module.exports = {
    generateOpenRouterResponse
};